# ProgrammingAssignment2

This Programming Assignment 2 was done by
- Tay Sze Chang 1004301
- Lee Jet Xuen 1004365

## How to Run

### To run Confidentiality Protocol 1: 

simply run each command in separate terminals in the following order:
 
1. On the first command :  
`cd CP1`  `  `  
`javac ServerCP1.java`  `  `  
`java ServerCP1.java`
2. On the second command :  
`cd CP1`  `  `  
`javac ClientCP1.java`  `  `  
`java ClientCP1.java *filename*`

An Example of second step with single file could be:  
`java ClientCP1.java 100000.txt`

Or with multiple files:  
`java ClientCP1.java 100000.txt 10000.txt 500.txt`

### To run Confidentiality Protocol 2: 

simply run each command in separate terminals in the following order:
 
1. On the first command :  
`cd CP2`  `  `  
`javac ServerCP2.java`  `  `  
`java ServerCP2.java`
2. On the second command :  
`cd CP2`  `  `  
`javac ClientCP2.java`  `  `  
`java ClientCP2.java *filename*`

An Example of second step with single file could be:  
`java ClientCP2.java 100000.txt`

Or with multiple files:  
`java ClientCP2.java 100000.txt 10000.txt 500.txt`